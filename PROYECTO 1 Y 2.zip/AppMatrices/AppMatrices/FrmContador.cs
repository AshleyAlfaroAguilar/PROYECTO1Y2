﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppMatrices
{
    public partial class FrmContador : Form
    {
        public FrmContador()
        {
            InitializeComponent();
        }


        int counter = 0;
        int valor = 0;
        private void btnIncrementar_Click(object sender, EventArgs e)
        {
            valor = Convert.ToInt32(lblcontador.Text);
            counter = valor;
            counter = counter + 1;

            lblcontador.Text = counter.ToString();
            if (counter > 0)
            {
                lblcontador.ForeColor = Color.Green;
            }
            else if (counter == 0)
            {
                lblcontador.ForeColor = Color.Blue;
            }
            else
            {
                lblcontador.ForeColor = Color.Red;
            }

        }

        private void btnDisminuir_Click(object sender, EventArgs e)
        {
            valor = Convert.ToInt32(lblcontador.Text);
            counter = valor;
            counter = counter - 1;

            lblcontador.Text = counter.ToString();
            if (counter > 0)
            {
                lblcontador.ForeColor = Color.Green;
            }
            else if (counter == 0)
            {
                lblcontador.ForeColor = Color.Blue;
            }
            else
            {
                lblcontador.ForeColor = Color.Red;
            }
        }

        private void btnReiniciar_Click(object sender, EventArgs e)
        {
            lblcontador.Text = "0";
            lblcontador.ForeColor = Color.Blue;
        }
    }
}
